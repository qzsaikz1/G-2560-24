/**
 * taem state.
 */
function about1() {
	Phaser.State.call(this);
	// TODO: generated method.
}

/** @type Phaser.State */
var proto = Object.create(Phaser.State.prototype);
about1.prototype = proto;
about1.prototype.constructor = about1;

about1.prototype.preload = function() {
	// TODO: generated method.
};

about1.prototype.create = function() {
	// TODO: generated method.
	
	this.bg = this.add.sprite(0,0,"past2");
	this.createButtons();
};
about1.prototype.createButtons = function() {
	this.btn_t = this.add.button(this.world.width-50,this.world.height-630 ,"back4team");
	this.btn_t.onInputDown.add(this.Gameabout1, this);
	this.btn_t.scale.set(0.3);
	this.btn_t.anchor.set(0.5,0);
	this.btn_t.isdown=false;
};

about1.prototype.update = function() {
	// TODO: generated method.
};
about1.prototype.Gameabout1 = function(){
	this.isdown=true;
	this.game.state.start("about2");
}