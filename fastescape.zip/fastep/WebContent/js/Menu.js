/**
 * Menu state.
 */
function Menu() {
	Phaser.State.call(this);
}

/** @type Phaser.State */
var proto = Object.create(Phaser.State);
Menu.prototype = proto;

Menu.prototype.preload = function() {
	this.load.pack("start", "assets/assets-pack.json");
};

Menu.prototype.create = function() {
	this.bg = this.add.sprite(0,0,"bg2");
	this.music = this.add.sound("music",1,true);
	var text = this.add.text(10, this.world.height-20, "2017 Game project by Asure",
			 {fill: 'white'});
			text.scale.set(0.4);
	this.music.play();
	
	 emitter = this.add.emitter(0, 0, 100);
	    emitter.makeParticles('bad2');
	    emitter.gravity = 250;

	    this.input.onDown.add(particleBurst, this);

	
	var sprite = this.add.sprite(this.world.centerX, this.world.height-100,
			"st");
	sprite.anchor.set(0.5, 0.5);
	sprite.scale.set(1);
	var logo =this.add.sprite(this.world.centerX,this.world.height-600,"Fast2");
	this.input.onDown.add(this.startGame, this);
	
	logo.scale.set(1);
	logo.anchor.set(0.5,0);
	
		this.chef = this.add.sprite(this.world.centerX, this.world.height-170,"CarRed");
		this.chef.animations.add("CarRed").play(12,true);
		this.chef.anchor.set(0.5,1);
		this.chef.scale.set(1.5);
		this.chef.smoothed = false;
		
	this.input.onDown.active=true;
	this.input.onDown.add(this.startGame, this);
	};

	function particleBurst(pointer) {

	    //  Position the emitter where the mouse/touch event was
	    emitter.x = pointer.x;
	    emitter.y = pointer.y;

	    //  The first parameter sets the effect to "explode" which means all particles are emitted at once
	    //  The second gives each particle a 2000ms lifespan
	    //  The third is ignored when using burst/explode mode
	    //  The final parameter (10) is how many particles will be emitted in this single burst
	    emitter.start(true, 2000, null, 100);
};

Menu.prototype.startGame = function() {
		this.input.onDown.active = true;
		var tw = this.add.tween(this.chef);
		tw.to({x:500},560, "Expo.easeIn",true);
		this.time.events.repeat(Phaser.Timer.SECOND * 2, 5, this.startLevel, this);
		};

Menu.prototype.startLevel = function() {
	this.game.state.start("Level");
	this.music.destroy();
};